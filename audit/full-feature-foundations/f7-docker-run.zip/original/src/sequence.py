def chunks(items):
    return [items]
