import pytest
@pytest.fixture
def items():
    return [1, 2]
