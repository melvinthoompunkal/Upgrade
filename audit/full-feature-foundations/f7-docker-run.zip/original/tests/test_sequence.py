from sequence import chunks
def test_chunks(items):
    assert chunks(items) == [[1, 2]]
