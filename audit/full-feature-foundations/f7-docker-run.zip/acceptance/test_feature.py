# Frozen controller-generated acceptance: python-function-acceptance-v1
import importlib
import json

def test_empty():
    module = importlib.import_module('sequence')
    function = getattr(module, 'chunks')
    args = json.loads('[[]]')
    kwargs = json.loads('{}')
    actual = function(*args, **kwargs)
    expected = json.loads('[]')
    if actual != expected:
        raise AssertionError('F7_EXPECTATION:empty')

